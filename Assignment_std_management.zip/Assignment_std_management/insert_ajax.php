<?php
  include('connection.php');
  // display--------
  if(isset($_GET['action']) && $_GET['action'] == 'Display')
  {
    $table = "<table class='table table-striped table-bordered table-hover'>";
        $table .= "<thead>
                    <tr class='thead-dark '>
                        <th>SL No.</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>School</th>
                        <th>Class</th>
                        <th>Division</th>
                        <th>Status</th>
                        <th>Operation</th>
                        

                    </tr>
                </thead>";
                $sql = "SELECT * FROM `students`";
                $result = mysqli_query($conn, $sql);
                $sno=1;
                if(mysqli_num_rows($result) > 0){
                    while($row=mysqli_fetch_assoc($result))
                    {
                        $id=$row['id'];
                        $name=$row['name'];
                        $age=strtotime($row['dob']);
                        $age = date('Y')-date('Y',$age);
                        $school=$row['school'];
                        $class = $row['class'];
                        $division = $row['division'];
                        $status = $row['status'];
                        $table.="<tr class='list-item'>
                            <td>$sno</td>
                            <td>$name</td>
                            <td>$age</td>
                            <td>$school</td>
                            <td>$class</td>
                            <td>$division</td>
                            <td>$status</td>
                            <td><button class='btn btn-warning'  onclick='updateUser(".$row['id'].")'>Update</button>
                            <button class='btn btn-danger' onclick='deleteUser(".$row['id'].")'>Delete</button></td>
                        </tr>";
                        $sno++;
                    }
                }
    $table.="</table>";
    echo $table;

  }

  // Search input----------
  else if(isset($_POST['input']))
  {
      
    $input = $_POST['input'];

    $query = " SELECT * FROM `students` WHERE name LIKE '%{$input}%' ";

    $result = mysqli_query($conn , $query);

    $sno = 1;
    if(mysqli_num_rows($result) > 0 )
    {
?>
        <table class="table table-striped table-bordered mt-4">
            <thead>
                <tr>
                    <th>Sl. No </th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>School</th>
                    <th>Class</th>
                    <th>Division</th>
                    <th>Status</th>
                    
                </tr>
            </thead>

            <tbody>
                <?php
                    while ( $row = mysqli_fetch_assoc($result)){
                        $sno;
                        $name = $row['name'];
                        $age=strtotime($row['dob']);
                        $age = date('Y')-date('Y',$age);
                        $school = $row['school'];
                        $class = $row['class'];
                        $division = $row['division'];
                        $status = $row['status'];
                ?>
                    <tr>
                        <td><?php echo $sno; ?></td>
                        <td><?php echo $name; ?></td>
                        <td><?php echo $age ?></td>
                        <td><?php echo $school; ?></td>
                        <td><?php echo $class; ?></td>
                        <td><?php echo $division; ?></td>
                        <td><?php echo $status; ?></td>
                        
                    </tr>

                <?php        
                   $sno++;
                 }
                ?>
            </tbody>
        </table>
        <?php
    }else{
        echo "<h4 class='text-danger text-center mt-3'>No data found.</h4>";
    }

    }

  else if(isset($_POST['action']) && $_POST['action'] == 'Insert')
  {
    $msg = '<h3 style="color:green">Data Inserted successfully.</h3>';
    $namesend = $_POST['namesend'];
    $dobsend = $_POST['dobsend'];
    $schoolsend = $_POST['schoolsend'];
    $classsend = $_POST['classsend']; 
    $divisionsend = $_POST['divisionsend']; 
    $statussend = $_POST['statussend'];
    $sql=" INSERT INTO `students` (name, dob, school, class, division, status) values ('$namesend', '$dobsend', '$schoolsend', '$classsend', '$divisionsend', '$statussend') ";
    if(mysqli_query($conn, $sql))
    {
        echo 'Success';
        echo $msg;
        header('location:students.php');
    }
    else
    {
        echo 'Error';
    }
  }

  else if(isset($_GET['action']) && $_GET['action'] == 'DeleteUser')
  {
        $del_id= $_GET['deleteid'];

        $sql = " DELETE FROM `students` WHERE id= '$del_id' ";
        if(mysqli_query($conn, $sql)){
            echo 'success';
        } else {
            echo 'error';
        }
  }


 else if(isset($_GET['action']) && $_GET['action'] == 'GetClass')
    {
        $value = $_GET['school'];
        $query = "SELECT `school`, `class`  FROM `students` WHERE school = '$value'";
        $result = mysqli_query($conn, $query);
        $count = mysqli_num_rows($result);

        if($count){
            '<option>Select Class</option>';

        }else{
            echo '<option>No Class Found !</option>';
        }

        while ($row = mysqli_fetch_array($result))
        { 
            echo '<option value="'.$row['class'].'" >'.$row['class'].'</option>';
        } 
    }

 else if(isset($_GET['action']) && $_GET['action'] == 'GetDivision')
    {
        $value = $_GET['class'];
        $query = "SELECT `class`, `division`  FROM `students` WHERE class = '$value'";
        $result = mysqli_query($conn, $query);
        $count = mysqli_num_rows($result);

        if($count){
            '<option>Select Class</option>';

        }else{
            echo '<option>No Division Found !</option>';
        }

        while ($row = mysqli_fetch_array($result))
        {            
            echo '<option value="'.$row['division'].'" >'.$row['division'].'</option>';
        } 
    }


    sleep(1);

    if(isset($_POST['action']) ){
    $action = $_POST['action'];

    $query = "SELECT * FROM `students` WHERE `division`  = '$action' ";
    $result = mysqli_query($conn, $query);
    $count = mysqli_num_rows($result);
    ?>

    <table class="table table-striped table-bordered table-hover">
    <?php
    if ($count){
    ?>
    <thead>
        <tr >
            <th>Sr</th>
            <th>Name</th>
            <th>Age</th>
            <th>School</th>
            <th>Class </th>
            <th>Division</th>
            <th>Status</th>
        </tr>
    <?php
    }else{
        echo "<h4 style='color:brown;text-align:center'>Sorry ! No record found.</h4>";
    }

    ?>
    </thead>

    <tbody>
    <?php
        $sr=1;
        while ($row = mysqli_fetch_assoc($result)){
            $age=strtotime($row['dob']);
            $age = date('Y')-date('Y',$age);
    ?>
        <tr >
            <td><?php echo $sr;  ?></td>
            <td><?php echo $row['name'];  ?></td>
            <td><?php echo $age;  ?></td>
            <td><?php echo $row['school'];  ?></td>
            <td><?php echo $row['class'];  ?></td>
            <td><?php echo $row['division'];  ?></td>
            <td><?php echo $row['status']; ?></td>
        </tr>
    <?php
    $sr++ ;    
        }
    }
    ?>
    </tbody>

    </table>

