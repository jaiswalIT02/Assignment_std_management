<?php
	session_start();
	
	if(isset($_SESSION['id']) == '' && isset($_SESSION['email']) == ''  && isset($_SESSION['password']) == ''){
		 header("Location:login.php");
	}
		include('connection.php');
		$query="SELECT * FROM `user_master`" ;
		$result=mysqli_query($conn,$query);
		while($row= mysqli_fetch_array($result)){
			$email=$row['email'];
			$password=$row['password'];
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   
    <title>Add Students Details</title>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" ></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
	
    <link src="style.css" type="text/css">
	
        
</head>
<body>
        
		<div class="conatainer">
			<div class="row bg-warning">
				<div class="col-lg-2">lead logo</div>
				<div class="col-lg-10">
				<?php
					if($_SESSION["email"])  {
				?>
					<h5 style="float: right;">Welcome <?php echo $_SESSION["email"]; } ?>
						<a href="logout.php">Logout</a>
					</h5>
				
				
				</div>
			</div>

			<div class="row">
				
					<div class="col-md-2 bg-primary text-center ">
						<button class="text-light btn btn-info"><a href="students.php" class="text-light" >Add Students</a></button>    <br><br>
						<button class="text-light btn btn-info"><a href="opn_students.php" class="text-light">View Students</a></button><br>
					</div>
			

				<div class="col-md-10 text-center ">
					<div class="card mt-3">
						<div class="card-header ">
							<div class="card-title">
								<h4>Add students :- </h4><hr>
							</div>	
						</div>
						<div class="card-body ">
							<div class="row">
								<div class="col-lg-12">

									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												Full Name
												<div class="controls">
													<div class="input-group">
														<div class="input-group-addon"></div>
														<input type="text"  class="form-control" id="name" >
													</div>
												</div>
											</div>
										</div>

										<div class="col-md-4">
											<div class="form-group">
												Date Of Birth 
												<div class="controls">
													<div class="input-group">
														<input type="date" id="dob" class="form-control" name="date" value="" required>
													</div>
												</div>
											</div>
										</div>

										<div class="col-md-4">
											<div class="form-group">
												School
												<div class="controls">
													<div class="input-group">
													<select  id="school" class="form-control select2" required>
														<option value="Null">Select School</option>
														<?php 
														$school = "";
														$sql2 = "SELECT `school_name` FROM `school` "; 
														$qry2 = mysqli_query($conn , $sql2);
														while($row2 = mysqli_fetch_array($qry2))
														{
															if ($row2['school_name'] == $school) {
																$select = $row2['school_name'];
															}else {
																$select = '';
															}			
														?>
														<option value="<?php echo $row2['school_name']; ?>" > <?php echo $row2['school_name']; ?></option>

													   <?php } ?>							
													</select>
														
													</div>
												</div>
											</div>
										</div>
									</div><br><br>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												Class	
												<div class="controls">
													<div class="input-group">
														<select name="" id="class" class="form-control" required>
															<option value="Null">Choose Class</option>
															<?php 
																$class = "";
																$sql2 = "SELECT `class` FROM `class` "; 
																$qry2 = mysqli_query($conn , $sql2);
																while($row2 = mysqli_fetch_array($qry2))
																{
																	if ($row2['class'] == $class) {
																		$select = $row2['class'];
																	}else {
																		$select = '';
																	}			
																?>
																<option value="<?php echo $row2['class']; ?>" > <?php echo $row2['class']; ?></option>

															<?php } ?>		
															
														</select>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												Division
												<div class="controls">
													<div class="input-group">
												        <select name="" id="division" class="form-control">
														    <option value="Null">Choose Division</option>
															<option value="A">A</option>
															<option value="B">B</option>
															<option value="C">C</option>
															<option value="D">D</option>
															<option value="E">E</option>
														</select>
													</div>
												</div>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												Status 
												<div >
													<label for="active">Active</label>
													<input type="radio" name="status" value="Active" id="active" >
													<label for="inactive">InActive</label>
													<input type="radio" name="status" value="Inactive" id="active" >
												</div>
											</div>
										</div>

										<div class="col-lg-12" style="margin-top:2.5%;">
											<button type="submit" onclick="adduser()"  class="btn btn-info">Submit</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script type="text/javascript">
		function adduser()
            {
				
                var name_add= $("#name").val();
                var dob_add= $("#dob").val();
                var school_add= $("#school").val();
                var class_add= $("#class").val();
				var division_add= $("#division").val();
				var status_add = $("#active").val();
				//var status_add_inactive= $("#inactive").val();

				//alert(status_add);

				if(status_add !=  'active'){
                     status_add = 'Inactive';
				}else{
					status_add = 'Active';					 
				}

				alert(status_add);


                $.ajax({	
                    url : "insert_ajax.php",
                    type : "POST",
                    data : {
                        namesend: name_add, dobsend : dob_add, schoolsend: school_add, classsend : class_add, divisionsend : division_add, statussend : status_add ,action : 'Insert'
                    },
					
                    success:function(data){
						confirm("Do you want to submit students details ?");
						
						console.log(data);

					}
				});
			}

	
		</script>
	</body>
</html>