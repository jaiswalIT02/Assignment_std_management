<?php
session_start();
session_destroy();


header("Location:index.php");
echo "Session is destroy";
session_write_close();
?>