

<?php
    $conn = mysqli_connect('localhost','root','','lead_assin') or die('Unable To connect'); 
?>
