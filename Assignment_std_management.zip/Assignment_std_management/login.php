<?php

session_start();
$message="";


if(count($_POST)>0) {
    include('connection.php');
    $result = mysqli_query($conn,"SELECT * FROM user_master WHERE email='" . $_POST["email"] . "' and password = '". $_POST["password"]."'");
    //echo $result;
    $row  = mysqli_fetch_array($result);
    if(is_array($row)) {
        $_SESSION["email"] = $row['email'];
        $_SESSION["password"] = $row['password'];
    }else {
        $message = "<span style='color:red'>Invalid email or Password!</span>";
       }
    }
    if(isset($_SESSION["email"])) {
    header("Location:students.php");

}
  


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" ></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
    <style src="css/style.css">
        body {  
    background-color: lightblue;  
}  
h1 {  
    color: navy;  
    margin-left: 20px;  
}   
    </style>
</head>
<body>
    <div class="container my-5">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header text-center"><h4>Login Here</h4>  </div>
                    <div class="card-body">
                        <form action="" method="post" name="myform">
                            
                            
                            <div class="form-group">
                                
                                <h5>Email / Mobile No.</h5>
                                <input type="text" class="form-control" name="email" placeholder="">
                            </div><br>

                            <div class="form-group">
                                <h5>Password</h5>
                                <input type="password" class="form-control" name="password" placeholder="">
                            </div><br>

                            <div class="form-group">
                                <button type="submit" name="submit" onclick="return validateform()" class="btn btn-primary form-control"> Login</button>
                            </div><br>

                            <div class="text-center">

                            <?php
                                if(isset($message)){
                                    echo $message ;
                                }
                            ?>

                            </div>
                            <a href="register.php">Register Here</a>
                                                                
                        </form>
                    </div>
                </div>
            </div>    
        </div>
    </div>

    <script>
    
    function validateform()
    {  
	
        var email=document.myform.email.value;  
		var password=document.myform.password.value; 
         
        var atposition=email.indexOf("@");  
        var dotposition=email.lastIndexOf("."); 
        //var y =document.getElementById("message").value; 
    
   
        if (atposition < 1 || dotposition<atposition+2 || dotposition+2>=email.length)
        {  
            alert("**Please enter a valid e-mail address \n such as 'example@gmail.com'");
            //alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
            return false;  
        }  

		if (password==null || password=="")
        {  
            alert("**Please input password field."); 
            return false;  

        }
    }  
    
    </script>
</body>
</html>