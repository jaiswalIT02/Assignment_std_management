<?php
	session_start();
	if(isset($_SESSION['id']) == '' && isset($_SESSION['email']) == ''  && isset($_SESSION['password']) == ''){
		 header("Location:login.php");
	}
        include('connection.php');                   
		//select query---------
		$query="SELECT * FROM `user_master`" ;
		$result=mysqli_query($conn,$query);
		while($row= mysqli_fetch_array($result)){
		$email=$row['email'];
		$password=$row['password'];
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   
    <title>Students Details</title>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" ></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
	
    <style >
        body{
            background-color: lightgray;
        }
    </style>
	
        
</head>
<body>
        
		<div class="conatainer">
			<div class="row bg-warning">
				<div class="col-lg-2">Lead LOGO</div>
				<div class="col-lg-10">
				<?php
					if($_SESSION["email"])  {
				?>
				    <h5 style="float: right;">Welcome <?php echo $_SESSION["email"]; } ?>
                        <a href="logout.php">Logout</a>
                    </h5>
				</div>
			</div>

			<div class="row">
				<div class="col-md-2 bg-primary text-center ">

                    <button class="text-light btn btn-info"><a href="students.php" class="text-light" >Add Students</a></button>    <br><br>

                    <button class="text-light btn btn-info"><a href="opn_students.php" class="text-light">View Students</a></button><br>

				</div>

				<div class="col-md-10">
					<div class="card mt-3">
						<div class="card-header ">
							<div class="card-title">
							 <h4>  Students Details :- </h4> <hr>
							</div>	
						</div><br>
                        <div class="row">
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                               <div class="col-md-2 ">
                                    <input type="text" id="name_search" class="form-control" placeholder="Search Name ... ">
                                </div>

                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <div class="controls">
                                        <div class="input-group">
                                        <select  id="school" class="form-control select2" onchange="select_school(this.value)">
                                            <option value="select">Select School</option>
                                            <?php 
                                            $school = "";
                                            $sql2 = "SELECT `school_name` FROM `school` GROUP BY `school_name` "; 
                                            $qry2 = mysqli_query($conn , $sql2);
                                            while($row2 = mysqli_fetch_array($qry2))
                                            {
                                                if ($row2['school_name'] == $school) {
                                                    $select = $row2['school_name'];
                                                }else {
                                                    $select = '';
                                                }			
                                            ?>                                            
                                            <option value="<?php echo $row2['school_name']; ?>" > <?php echo $row2['school_name']; ?></option>
                                        <?php } ?>							
                                        </select>
                                        </div>
									</div>
								</div>
							</div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <div class="controls">
                                        <div class="input-group">
                                        <select  id="class" class="form-control select2" onchange="select_class(this.value)">
                                            <option value="Null">Select Class</option>
                                            <?php 
                                                $class = "";
                                                $sql2 = "SELECT `class` FROM `students` GROUP BY `class`";
                                                $qry2 = mysqli_query($conn , $sql2);
                                                while($row2 = mysqli_fetch_array($qry2))
                                                {
                                                    if ($row2['class'] == $class) {
                                                        $select = $row2['class'];
                                                    }else {
                                                        $select = '';
                                                    }			
                                                ?>
                                                <option value="<?php echo $row2['class']; ?>" > <?php echo $row2['class']; ?></option>

                                            <?php } ?>		

                                        </select>
                                        </div>
									</div>
								</div>
							</div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <div class="controls">
                                        <div class="input-group">
                                        <select  id="division" class="form-control select2" onchange="select_division(this.value)">
                                            <option value="select">Select Division</option>

                                            <option value="A">A</option>		
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>
                                            <option value="E">E</option>				
                                        </select>
                                        </div>
									</div>
								</div>
							</div>
                            

                        </div>

						<div class="card-body">
                                <div id="display_data_table" style="overflow: auto;height:400px">
                                </div>
						</div>

                        <a href="export.php">  <button class="btn btn-primary text-center">Export to Excel</button></a>
					</div>
				</div>
			</div>	
		</div>
<script src="jquery/jquery.js"></script>
<script type="text/javascript">
        $(document).ready(function(){
                displaydata();
        });

        // main display details of students in table as default--------------
        function displaydata()
            {
            $.ajax({
                url : "insert_ajax.php?action=Display",
                success : function (data)
                {
                    console.log(data);
                    $('#display_data_table').html(data)
                }
            });
            }

        // Students inserting function-----------------    
		function adduser()
            {
                var name_add= jquery("#name").val();
                var dob_add= $("#dob").val();
                var school_add= $("#school").val();
                var class_add= $("#class").val();
				var division= $("#division").val();
                
                $.ajax({	
                    url : "insert_ajax.php",
                    type : "post",
                    data : {
                        namesend: name_add, dobsend : dob_add, schoolsend: school_add, classsend : class_add, divisionsend : division_add ,action : 'Insert'
                    },
                    success:function(data){
                        confirm('Are you sure want to submit details ?')
						console.log(data);
					}
				});
			}

            // Delete function ---------------
            function deleteUser(deleteid)
            {
                $.ajax({
                    url : "insert_ajax.php?action=DeleteUser&deleteid=" +deleteid,
                    success:function(data)
                    {   
                        if(data == "success"){
                            alert('Delete Successfully');
                            displaydata();
                        } else {
                            alert('Error');
                        }                                    
                    }
                });
            }

            // Live Search for-----------------
            $(document).ready(function()
            {
                $("#name_search").keyup(function(){
                    var inputValue = $(this).val().toLowerCase();
                    /*if(input != ""){ 
                        $.ajax({
                            url : "insert_ajax.php",
                            method : "POST",
                            data : {input : input},
                            success : function(data){
                                $("#display_data_table").html(data);
                            }
                        });
                    }else{
                        displaydata();
                        $("#display_data_table").css("display", "none");
                    } */
                    $('.list-item').hide();
                    let listItems = $('.list-item');
                    listItems.each(function(){
                        if($(this).inputValue().toLowerCase().match(inputValue)){
                            $(this).show();
                        }else{
                            $(this).hide();
                        }
                   });
                });
            });

        // School Selector for filter ------
        function select_school(school)
        {
        $.ajax({
			url:  "insert_ajax.php?action=GetClass&school="+ school,
			success: function(data)
			{
				console.log(data);
				$("#class").html(data)
			}
		});
        }

        // Class selector filter -------
        function select_class(clas)
        {
        $.ajax({
			url:  "insert_ajax.php?action=GetDivision&class="+ clas,
			success: function(data)
			{
				console.log(data);
				$("#division").html(data)
			}
		});
        }

        // Division Selector and Found details in table----
        function select_division(division)
        {
            $.ajax({
                url:  "insert_ajax.php",
                type: "POST",
                data : 'action=' + division,
                beforeSend: function(){
                    $("#display_data_table").html("<span>Searching...</span>");
                },
                success: function(data){
                    $("#display_data_table").html(data)
                }
            });
        }
        
        </script>
    </body>
</html>