<?php


if(isset($_POST['submit'])){
        include('connection.php');
        $id= $_POST['id'];
        $email=$_POST['email'];
        $password= $_POST['password'];
        $sql="INSERT INTO `user_master` (id,email,password) values('$id','$email','$password')" ;
        $query = mysqli_query($conn,$sql);
        $message = " <span style='color:green;'>Inserted Successfully.</span>";
        header('location:register.php');
        
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" ></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
    <link src="style.css" type="text/css" rel="stylesheet">
    <style>
        body {  
    background-color: lightblue;  
}  
h1 {  
    color: navy;  
    margin-left: 20px;  
}   
    </style>
        

</head>
<body>
    <div class="container my-5">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header"><h4>Create A New Account</h4>  </div>
                    <div class="card-body">

                        
                            <form action="register.php" method="post" name="myform">
                                <div class="form-group">
                                    <input type="hidden" name="id">
                                   <h5>Email :</h5> 
                                    <input type="eamil" class="form-control" name="email" placeholder="">
                                </div><br>

                                <div class="form-group">
                                   <h5>Password :</h5> 
                                    <input type="password" class="form-control" name="password" placeholder="">
                                </div><br>

                                <div class="form-group">
                                      <button type="submit" name="submit" onclick="return validateform()" class="btn btn-primary form-control"> Register</button>
                                </div><br>

                                <div class="text-center">

                                    <?php
                                        if(isset($message)){
                                            echo $message ;
                                        }
                                    ?>

                                </div>
                                <a href="login.php">Login here</a>

                            </form>

                        
                    </div>
                </div>
            </div>    
        </div>
    </div>

    <script>
    
    function validateform()
    {  
	
        var email=document.myform.email.value;  
		var password=document.myform.password.value; 
         
        var atposition=email.indexOf("@");  
        var dotposition=email.lastIndexOf("."); 
        //var y =document.getElementById("message").value; 
    
   
        if (atposition < 1 || dotposition<atposition+2 || dotposition+2>=email.length)
        {  
            alert("**Please enter a valid e-mail address \n such as 'example@gmail.com'");
            //alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
            return false;  
        }  

		if (password==null || password=="")
        {  
            alert("**Please input password field."); 
            return false;  

        }

		confirm("Do you want to sumbit your details ?");
    }  
    
    </script>
</body>
</html>