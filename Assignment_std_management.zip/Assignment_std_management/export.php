<?php

include('connection.php');
$query="SELECT * FROM `students`" ;
$result=mysqli_query($conn,$query);
$sr= 1;
$data= "<table class='table table-striped table-bordered table-hover'><tr>
                   <th>Sr.No.</th>
                   <th>Name</th>
                   <th>Age</th>
                   <th>School</th>
                   <th>Class</th>
                   <th>Division</th>
                </tr>";

while($row= mysqli_fetch_array($result)){
    $a= strtotime( $row['dob']);
    $age=  date("Y")-date('Y',$a);
$data .=   '<tr>
                    <td>'.$sr.'</td>
                    <td>'.$row['name'].'</td>
                    <td>'.$age.'</td>
                    <td>'.$row['school'].'</td>
                    <td>'.$row['class'].'</td>
                    <td>'.$row['division'].'</td>
                </tr>';
$sr++;
}


$data .="</table>";
header('Content-Type:application/xls');
header('Content-Disposition:attachment;filename=students_details.xls');
echo $data;
                  
?>